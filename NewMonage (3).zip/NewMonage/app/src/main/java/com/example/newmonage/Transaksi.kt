package com.example.newmonage

data class Transaksi(val tanggal:String, val label: String, val jumlah: Double, ){
}