package com.example.newmonage

import android.database.sqlite.SQLiteTransactionListener
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var transactions: ArrayList<Transaksi>
    private lateinit var transaksiAdapter: AdapterTransaksi
    private lateinit var linearlayoutManager:LinearLayoutManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        transactions = arrayListOf(
            Transaksi("10 September", "makan", 400.00),
            Transaksi("11 September", "makan", 500.00),
            Transaksi("12 September", "makan", -200.00),
            Transaksi("13 September", "makan", 200.00)
        )

        transaksiAdapter = AdapterTransaksi(transactions)
        linearlayoutManager = LinearLayoutManager(this)

        recyclerview.apply {
            adapter = transaksiAdapter
            layoutManager = linearlayoutManager
        }

        updateDashboard()
    }
    private fun updateDashboard(){
        val totalAmount = transactions.map { it.jumlah }.sum()
        val budgetAmount = transactions.filter { it.jumlah>0 }.map { it.jumlah }.sum()
        val expenseAmount = totalAmount-budgetAmount

        saldo.text = "Rp %.2f".format(totalAmount)
        pemasukan.text = "Rp %.2f".format(budgetAmount)
        pengeluaran.text = "Rp %.2f".format(expenseAmount)
    }
}