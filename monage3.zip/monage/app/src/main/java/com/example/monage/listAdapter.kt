package com.example.monage

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class listAdapter (private var transactions: List<Model>) :
        RecyclerView.Adapter<listAdapter.TransactionHolder>() {

        class TransactionHolder(view: View) : RecyclerView.ViewHolder(view) {
            val label : TextView = view.findViewById(R.id.title)
            val amount : TextView = view.findViewById(R.id.amount)
            val tanggal : TextView = view.findViewById(R.id.tanggal)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TransactionHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.itemlist, parent, false)
            return TransactionHolder(view)
        }

        override fun onBindViewHolder(holder: TransactionHolder, position: Int) {
            val transaction = transactions[position]
            val context = holder.amount.context

            if(transaction.Amount >= 0){
                holder.amount.text = "+ Rp.%.2f".format(transaction.Amount)
                holder.amount.setTextColor(ContextCompat.getColor(context, R.color.green))
            }else {
                holder.amount.text = "- Rp.%.2f".format(Math.abs(transaction.Amount))
                holder.amount.setTextColor(ContextCompat.getColor(context, R.color.red))
            }

            holder.label.text = transaction.Label
            holder.tanggal.text = transaction.Tanggal

            holder.itemView.setOnClickListener {
                val intent = Intent(context, updateTran::class.java)
                intent.putExtra("home", transaction)
                context.startActivity(intent)
            }
        }

        override fun getItemCount(): Int {
            return transactions.size
        }

        fun setData(transactions: List<Model>){
            this.transactions = transactions
            notifyDataSetChanged()
        }
    }