package com.example.monage

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class addtransaction : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_addtransaction)

                labelInput.addTextChangedListener {
                    if(it!!.count() > 0)
                        labelLayout.error = null
                }

                amountInput.addTextChangedListener {
                    if(it!!.count() > 0)
                        amountLayout.error = null
                }

                addTransactionBtn.setOnClickListener {
                    val label = labelInput.text.toString()
                    val description = descriptionInput.text.toString()
                    val amount = amountInput.text.toString().toDoubleOrNull()

                    if(label.isEmpty())
                        labelLayout.error = "Please enter a valid label"

                    else if(amount == null)
                        amountLayout.error = "Please enter a valid amount"
                    else {
                        val transaction  =Transaction(0, label, amount, description)
                        insert(transaction)
                    }
                }

                closeBtn.setOnClickListener {
                    finish()
                }
            }

}